import React, { Component } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import "./css.css/signin.css"

export default class Login extends Component {
  


  render() {
    return (  

        <div class="signtop">
          <div class ="container">
              <div class ="row">
                  <div class="mt-4 col-md-12 text-center"><h2 class="title">The flavors of life are just a bite away</h2></div>
                  <div class="mt-2 border p-4 col-md-6 ltc"></div>
      
                  <div class ="col-md-6">
                      <div class="signin-form">
                          <form action="" class="mt-5 border p-4 bg-light shadow custom-fix">
                              <h3 class="mb-4 ">Sign-In</h3>
                              <div class="row">
                                  <div class="mb-3 col-md-6">
                                      <label for="email">E-mail address</label>
                                      <input type ="email" id="email" name="email" class="form-control" placeholder="Enter email "></input>
                                  </div>
                                  
                                  <div class="mb-3 col-md-12">
                                      <label>Password</label>
                                      <input type ="password" name="password" class="form-control" placeholder="Enter Password"></input>
                                  </div>
      
                                  <div class="mb-1 col-md-12 text-center">
                                      <button class="btn btn-primary">Sign In</button>
                                  </div>

                                  <div class="mb-1 col-md-12 text-center">
                                      <a href="a">SignUp</a>
                                  </div>
                                
                              </div>
                          </form>
                      </div>
                  </div>
                </div>
          </div>
        </div>
   
    );
  }
}