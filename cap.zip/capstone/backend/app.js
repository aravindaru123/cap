const express= require("express");
const app=express();
const mongoose=require("mongoose");
app.use(express.json);
const cors= require("cors");
app.use(cors());

// const bcrypt = require("bcryptjs");

// const jwt = require("jsonwebtoken");

const JWT_SECRET =
  "hvdvay6ert72839289()aiyg8t87qt72393293883uhefiuh78ttq3ifi78272jbkj?[]]pou89ywe";

const mongoUrl="mongodb+srv://aravind2022:1234@cluster0.ldjartl.mongodb.net/?retryWrites=true&w=majority"

mongoose
    .connect(mongoUrl, {
        useNewUrlParser:true,
    })
    .then(()=> {
    console.log("mongo connected"); 
    })
    .catch((e)=> console.log(e));

require("./schema");

const User = mongoose.model("UserInfo");

app.post("/register", async(req, res) => {
    const {fname, lname, email, password} = req.body;
    console.log(req.body);
    try{
        await User.create({
                fname,
                lname,
                email,
                password,
        });
        res.send({ status: "ok"});
    } catch(error){
        res.send({status:"error"});
    }
});

app.listen(5000,()=>{
    console.log("server started");
});